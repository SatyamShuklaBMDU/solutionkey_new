<div class="footer_part">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-sm-12">
                <div class="footer_iner text-center">
                    <p class="mt-3 mb-3 text-primary">2024 © Solutions Key</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
