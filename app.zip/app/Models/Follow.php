<?php

namespace App\Models;

use App\Providers\NewFollowCreated;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Follow extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
    protected $dispatchesEvents = [
        'created' => NewFollowCreated::class
    ];
}
